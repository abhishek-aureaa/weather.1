// Copyright (c) 2014, Ruslan Baratov
// All rights reserved.

#import <UIKit/UISearchBar.h>

@interface SearchBar: UISearchBar
- (void)first_responder:(BOOL)is_first_responder;
@end
