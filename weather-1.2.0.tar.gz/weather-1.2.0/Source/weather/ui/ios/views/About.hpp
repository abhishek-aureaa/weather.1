// Copyright (c) 2014, Ruslan Baratov
// All rights reserved.

#import <UIKit/UITableViewController.h>

@interface About: UITableViewController <UITableViewDelegate>
@end
